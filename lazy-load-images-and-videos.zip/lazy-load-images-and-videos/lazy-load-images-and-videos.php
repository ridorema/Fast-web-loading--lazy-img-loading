<?php
/*
Plugin Name: Lazy Load Images and Videos
Description: Delays loading images and videos until they are scrolled into view for improved performance.
Version: 1.0
Author: Rido Rema
*/

// Enqueue scripts and styles
function lazy_load_enqueue_scripts() {
    wp_enqueue_script('lazy-load-script', plugins_url('js/lazy-load.js', __FILE__), array('jquery'), '1.0', true);
    wp_enqueue_style('lazy-load-style', plugins_url('css/style.css', __FILE__), array(), '1.0');
}
add_action('wp_enqueue_scripts', 'lazy_load_enqueue_scripts');

// Include additional functionalities
require_once plugin_dir_path(__FILE__) . 'inc/lazy-load.php';
// You might have more 'require_once' statements for other functionalities

// Additional hooks, filters, and initialization can go here
