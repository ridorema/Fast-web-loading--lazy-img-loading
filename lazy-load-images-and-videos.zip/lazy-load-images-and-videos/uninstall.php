<?php
// If uninstall is not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit();
}

// Delete plugin options
delete_option('lazy_load_images_and_videos_option1');
delete_option('lazy_load_images_and_videos_option2');
// Add more delete_option lines for each option set by the plugin

// Remove any additional data or settings as needed
// For instance, deleting custom post types, tables, etc.
// delete_post_meta_by_key('your_custom_meta_key');
// drop_custom_tables();

// Clear any other data specific to your plugin

// Note: Be cautious while deleting options or data as this action is irreversible

// Clean up any additional tasks specific to your plugin upon uninstallation
